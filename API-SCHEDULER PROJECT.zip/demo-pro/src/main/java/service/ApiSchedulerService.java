package service;

import java.time.LocalDateTime;
import model.ApiEntity;
import repository.ApiScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ApiSchedulerService {

    @Autowired
    private ApiScheduleRepository apiEntityRepository;

    // Method to add a new API schedule
    public ApiEntity addApi(ApiEntity apiEntity) {
        return apiEntityRepository.save(apiEntity);
    }

    // Method to update an existing API schedule
    public ApiEntity updateApi(Long id, ApiEntity updatedApi) {
        Optional<ApiEntity> existingApiOptional = apiEntityRepository.findById(id);

        if (existingApiOptional.isPresent()) {
            ApiEntity existingApi = existingApiOptional.get();
            // Update fields with new values
            existingApi.setUrl(updatedApi.getUrl());
            existingApi.setMethod(updatedApi.getMethod());
            existingApi.setIntervalInMinutes(updatedApi.getIntervalInMinutes());
            existingApi.setNextExecutionTime((LocalDateTime) updatedApi.getNextExecutionTime());
            
            return apiEntityRepository.save(existingApi);
        } else {
            throw new IllegalArgumentException("API with ID " + id + " does not exist.");
        }
    }

    // Method to delete an API
    public void deleteApi(Long id) {
        apiEntityRepository.deleteById(id);
    }

    // Method to trigger an API manually
    public void triggerApi(Long id) {
        ApiEntity apiEntity = apiEntityRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("API with ID " + id + " not found."));
        // Logic to trigger the API manually
        executeApi(apiEntity);
        updateExecutionTime(apiEntity);
    }

    private void executeApi(ApiEntity apiEntity) {
        // Implementation of executeApi method from previous service code
    }

    private void updateExecutionTime(ApiEntity apiEntity) {
        // Implementation of updateExecutionTime method from previous service code
    }

    public void scheduleApis() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
