
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CacheService {

    private Map<Long, String> apiResponseCache = new HashMap<>();

    public String getCachedResponse(Long apiId) {
        return apiResponseCache.get(apiId);
    }

    public void cacheApiResponse(Long apiId, String response) {
        apiResponseCache.put(apiId, response);
    }
}
