package repository;

import model.ApiEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiScheduleRepository extends JpaRepository<ApiEntity, Long> {}