package scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import service.ApiSchedulerService;


@Component
public class ApiTaskScheduler {

    private final ApiSchedulerService apiSchedulerService;

    // Constructor-based dependency injection
    public ApiTaskScheduler(ApiSchedulerService apiSchedulerService) {
        this.apiSchedulerService = apiSchedulerService;
    }

    // This method will run every 60 seconds (60000 ms)
    @Scheduled(fixedRate = 60000)
    public void executeScheduledApis() {
        apiSchedulerService.scheduleApis();
    }
}
