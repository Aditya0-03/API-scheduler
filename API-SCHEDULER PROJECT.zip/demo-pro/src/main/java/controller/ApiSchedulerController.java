package controller;

import model.ApiEntity;  // Change here
import service.ApiSchedulerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/scheduler")
public class ApiSchedulerController {

    @Autowired
    private ApiSchedulerService apiSchedulerService;

    @PostMapping
    public ResponseEntity<ApiEntity> addApi(@RequestBody ApiEntity apiEntity) {  // Change here
        return ResponseEntity.ok(apiSchedulerService.addApi(apiEntity));  // Change here
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiEntity> updateApi(@PathVariable Long id, @RequestBody ApiEntity apiEntity) {  // Change here
        return ResponseEntity.ok(apiSchedulerService.updateApi(id, apiEntity));  // Change here
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteApi(@PathVariable Long id) {
        apiSchedulerService.deleteApi(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/trigger/{id}")
    public ResponseEntity<Void> triggerApi(@PathVariable Long id) {
        apiSchedulerService.triggerApi(id);
        return ResponseEntity.ok().build();
    }
}